// frontend/src/pages/BotList.jsx

import React from "react";

export default function BotList() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Liste des bots actifs</h2>
      <p>Cette section affichera les bots en cours d'exécution.</p>
    </div>
  );
}
