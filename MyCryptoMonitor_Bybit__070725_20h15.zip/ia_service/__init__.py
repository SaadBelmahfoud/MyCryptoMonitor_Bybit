# File: ia_service/__init__.py

# Ce fichier permet à Python de traiter ce dossier comme un package
